<?php
/**
 * Created by PhpStorm.
 * User: rebec
 * Date: 5/10/2017
 * Time: 2:50 AM
 */?>
<br><br><br>
<div class="row text-center" style="background-color: #B64136">
    <img src="/images/footerlogo.png">
</div>