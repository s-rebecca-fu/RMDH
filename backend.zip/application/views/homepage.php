<br><br><br><br><br>
<div class="row">
    <div class="col-sm-6">
        <div class="span6 text-center"><img src="/images/logo.png"/></div>
    </div>
    <div class="col-sm-6 weltext">
            <br>
            {message}
            <br>
            <form action="/user/check" method="post">
                <div class="row">
                    <div class="col-sm-2">Username: </div>
                    <div class="col-sm-6"><input type="text" class="form-control" name="user"> </div>
                    <div class="col-sm-4"></div>
                </div>
                 <br><br>
                <div class="row">
                    <div class="col-sm-2">Password: </div>
                    <div class="col-sm-6"><input type="password" class="form-control" name="pwd"></div>
                    <div class="col-sm-4"></div>
                </div>
                <br>
                <div class="row">
                    <div class="col-sm-4 text-center"><input type="submit"  class="btn"> </div>
                    <div class="col-sm-5 text-center"><input type="reset" class="btn"></div>
                    <div class="col-sm-3"></div>
                </div>

            </form>
        </div>
    </div>
</div>

