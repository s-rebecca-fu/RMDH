<?php
/**
 * Created by PhpStorm.
 * User: rebec
 * Date: 5/9/2017
 * Time: 11:06 PM
 */
?>

<div class="row">
    <img src="/images/smallogo.png"/>
</div>
<div class="row">
    <div class="col-xs-10 alert menurbg text-center">
        <div class="col-xs-1"><a class="menu" href="/story/">Home</a></div>
        <div class="col-xs-1"><a class="menu" href="/story/get/all">Story</a></div>
        <div class="col-xs-2 text-left"><a class="menu" href="/user/">User</a></div>
        <div class="col-xs-8"></div>
    </div>
    <div class="col-xs-2 text-center alert menugbg menutext">
        <a class="menu" href="/user/logout">Log Out</a>
    </div>
</div>
<br>





















<!--/user/logout-->