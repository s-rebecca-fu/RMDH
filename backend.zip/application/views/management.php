<?php
/**
 * Created by PhpStorm.
 * User: rebec
 * Date: 5/4/2017
 * Time: 1:05 AM
 */?>
{menubar}

<div class="row text-center weltext">
    <br><br><br>
    <h2>{user}</h2><br>
    <h2>
        Welcome to Data Management System
    </h2>
    <br><br><br>
</div>

{footer}


