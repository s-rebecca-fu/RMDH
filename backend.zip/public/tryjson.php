<?php
var_dump(preg_match('/[a-l]/','a'));